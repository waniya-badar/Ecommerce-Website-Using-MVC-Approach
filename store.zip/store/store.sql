SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `products` (`id`, `category_id`,  `title`, `description`, `image`, `price`) VALUES
(16, 1, 'Polos', 'Polos are great and modern!', 'm1.png', 14),
(17, 1, 'Denim Jeans', 'Great for activities', 'm2.png', 11),
(18, 2, 'Skirts', 'Perfect and airy', 'w1.png', 13),
(19, 2, 'Dresses', 'Feminine touch', 'w2.png', 15),
(20, 3, 'Rompers', 'Infants love this', 'k2.png', 18),
(25, 4, 'Turtlenecks', 'Warm for cozy weather', 'wi1.png', 22),
(26, 7, 'Tracksuits', 'Great for athletics', 'a1.png', 19),
(27, 6, 'Kalidaar', 'Perfect for fusion', 'e1.png', 12);


CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `categories` (`id`, `name`, `description`) VALUES
(1, 'Mens Clothing', 'Modern fits and timeless style.'),
(2, 'Womens Clothing', 'Chic, confident, and curated just for her.'),
(3, 'Kids Clothing', 'Adorable outfits for every little adventure.'),
(4, 'Winter Wear', 'Stay warm in style with our cozy winter essentials.'),
(5, 'Summer Wear', 'Breezy looks and cool comfort for sunny days.'),
(6, 'Ethnic Wear', 'Celebrate tradition with a touch of modern elegance.'),
(7, 'Activewear', 'Gear up with outfits that move with you.'),
(8, 'Formal Wear', 'Sharp, sophisticated styles for work and beyond.'),
(9, 'Casual Wear', 'Laid-back fashion made for everyday living.'),
(10, 'Accessories', 'Complete your look with the perfect finishing touch.');


CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`) VALUES
(1, 'hassan', 'hassan@gmail.com', '$2y$10$e6q33tEQSyEzOj/ngcikMua8mRdzsSmPua7Lm2vVt.1Jq0Dt.n6mW', 1),
(10, 'mustafa', 'mustapha@gmail.com', '$2y$10$2YQZkCSDHkGJZn6HWbrkVOKUqEuqqUYP9s7eoVE6kegw8IEYQDsm.', 0);


ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_id` (`category_id`);

ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
  

COMMIT;
