<?php

class Product
{
  public $id;
  public $category_id;
  public $title;
  public $description;
  public $image;
  public $price;


  public function __construct()
  {
    $this->db = new Database();
  }

  public function add_product()
  {
    $this->db->prepare(
      "INSERT INTO products (category_id, title, description, image, price) VALUES (:category_id, :title, :description, :image, :price)"
    );

    $this->db->bind(':category_id', $this->category_id);
    $this->db->bind(':title', $this->title);
    $this->db->bind(':description', $this->description);
    $this->db->bind(':image', $this->image);
    $this->db->bind(':price', $this->price);

    if ($this->db->execute()) {
      return true;
    } else {
      return false;
    }
  }

  public function get_products()
  {
    $this->db->prepare("SELECT products.*, categories.*, products.id as `product_id`, products.description as `product_description`,categories.id as `category_id`, categories.name as `category_name`, categories.description as `category_description` FROM products INNER JOIN categories ON categories.id = products.category_id
    ");

    $this->db->execute();

    return $this->db->get_all();
  }

  public function get_product($id)
{
  $this->db->prepare("SELECT products.*, categories.*, products.id as `product_id`, products.description as `product_description`, categories.id as `category_id`, categories.name as `category_name`, categories.description as `category_description` 
    FROM products 
    INNER JOIN categories ON categories.id = products.category_id 
    WHERE products.id = :id
  ");

  $this->db->bind(':id', $id); 
  $this->db->execute();

  return $this->db->get_one();
}


  public function update_product($id)
  {
    $this->db->prepare("UPDATE products SET category_id = :category_id, title = :title, description = :description, image = :image, price = :price WHERE id = :id");

    $this->db->bind(':id', $id);
    $this->db->bind(':category_id', $this->category_id);
    $this->db->bind(':title', $this->title);
    $this->db->bind(':description', $this->description);
    $this->db->bind(':image', $this->image);
    $this->db->bind(':price', $this->price);

    if ($this->db->execute()) {
      return true;
    } else {
      return false;
    }
  }

  public function get_products_by_category($category_id)
  {
    $this->db->prepare("SELECT products.*, categories.*, products.id as `product_id`, products.description as `product_description`,categories.id as `category_id`, categories.name as `category_name`, categories.description as `category_description` FROM products INNER JOIN categories ON categories.id = products.category_id WHERE products.category_id = '$category_id'
    ");
    $this->db->execute();
    return $this->db->get_all();
  }


  public function delete_product()
  {
    $this->db->prepare("DELETE FROM products WHERE id = :id");

    $this->db->bind(':id', $this->id);

    if ($this->db->execute()) {
      return true;
    } else {
      return false;
    }
  }

}
