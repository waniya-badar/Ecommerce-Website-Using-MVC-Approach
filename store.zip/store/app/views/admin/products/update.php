<?php require APPROOT . '/views/admin/includes/header.php' ?>

<div class="container-fluid">
  <div class="row">
    <?php require APPROOT . '/views/admin/includes/sidebar.php' ?>
      <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
      <div class="categories__create mt-5">
        <div class="row justify-content-center">
          <div class="col">
            <div class="card">
              <div class="card-header">
                <h4 class="text-center">Update</h4>
              </div>
              <div class="card-body">
                <form action="" method="POST" enctype="multipart/form-data">

                  <div class="form__content row">

                    <div class="col-12 col-md-6">
                      <div class="form-group mb-3">
                        <label for="title" class="mb-2">Title : <sup class="text-danger">*</sup></label>
                        <input type="text" name="title" class="form-control form-control-lg <?php echo (!empty($data['title_error'])) ? 'is-invalid' : ''; ?>" value="<?php echo $data['title']; ?>">
                        <span class="invalid-feedback"><?php echo $data['title_error']; ?></span>
                      </div>
                      <div class="form-group mb-3">
                        <label for="description" class="mb-2">Description : <sup class="text-danger">*</sup></label>
                        <textarea name="description" class="form-control form-control-lg <?php echo (!empty($data['description_error'])) ? 'is-invalid' : ''; ?>"><?php echo $data['description']; ?></textarea>
                        <span class="invalid-feedback"><?php echo $data['description_error']; ?></span>
                      </div>
                      <div class="form-group mb-3">
                        <label for="price" class="mb-2">Price : <sup class="text-danger">*</sup></label>
                        <input type="number" name="price" class="form-control form-control-lg <?php echo (!empty($data['price_error'])) ? 'is-invalid' : ''; ?>" value="<?php echo $data['price']; ?>">
                        <span class="invalid-feedback"><?php echo $data['price_error']; ?></span>
                      </div>
                      <div class="form-group mb-3">
                        <label for="image" class="mb-2">Image : <sup class="text-danger">*</sup></label>
                        <input type="file" name="image" class="form-control form-control-lg <?php echo (!empty($data['image_error'])) ? 'is-invalid' : ''; ?>" value="<?php echo $data['image']; ?>">
                        <span class="invalid-feedback"><?php echo $data['image_error']; ?></span>
                      </div>
                    </div>
                        <select class="form-select" name="category_id">
                          <?php foreach ($data['categories'] as $category) : ?>
                            <option value="<?php echo $category->id; ?>" <?php echo ($data['category_id'] == $category->id) ? 'selected' : ''; ?>><?php echo $category->name; ?></option>
                          <?php endforeach; ?>
                        </select>

                        <div class="invalid-feedback">Example invalid select feedback</div>
                      </div>

                  </div>

                  <div class="row mt-3 form__footer">
                    <div class="col form__footer__right">
                      <input type="submit" value="Update" class="btn btn-success d-block form__btn">
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>

    </main>
  </div>
</div>
