<?php require APPROOT . '/views/admin/includes/header.php' ?>

<div class="container-fluid">
  <div class="row">
    <?php require APPROOT . '/views/admin/includes/sidebar.php' ?>

    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
      
      <div class="categories">
        <div class="row">
          <div class="col">
            <div class="card">
              <div class="card-header d-flex justify-content-between">
                <h4>products</h4>
                <a href="<?php echo URLROOT; ?>/products/create" class="btn btn-success"><i class="fa-solid fa-plus"></i></a>
              </div>
              <div class="card-body">

                <div class="table-responsive">
                  <table class="table table-bordered">
                    <thead class="table-light">
                      <tr>
                        <th>#</th>
                        <th>Title</th>
                        <th>Category</th>
                        <th>Price</th>
                        <th>Image</th>
                        <th>Upadate</th>
                        <th>Delete</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php foreach ($data['products'] as $product) : ?>
                        <tr>
                          <td><?php echo $product->product_id; ?></td>
                          <td><?php echo $product->title; ?></td>
                          <td><?php echo $product->category_name; ?></td>
                          <td><?php echo $product->price; ?></td>
                          <td class="text-center">
                            <img src="<?php echo URLROOT; ?>/images/products/<?php echo $product->image; ?>" alt="<?php echo $product->title; ?>" class="img-fluid" width="50">
                          </td>
                          <td class="text-center pt-3">
                            <a href="<?php echo URLROOT; ?>/products/update/<?php echo $product->product_id; ?>" class="btn btn-primary btn-sm">
                              <i class="fa-solid fa-pencil"></i>
                            </a>
                          </td>
                          <td class="text-center pt-3">
                            <a href="<?php echo URLROOT; ?>/products/delete/<?php echo $product->product_id; ?>" class="btn btn-danger btn-sm">
                              <i class="fa-solid fa-trash"></i>
                            </a>
                          </td>
                        </tr>
                      <?php endforeach; ?>
                    </tbody>
                  </table>
                </div>

              </div>
            </div>
          </div>
        </div>
      </div>
  </div>
  </main>
</div>
</div>
