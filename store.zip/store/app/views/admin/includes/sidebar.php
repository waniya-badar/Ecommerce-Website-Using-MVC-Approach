<nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
  <div class="position-sticky pt-3">
    <ul class="nav flex-column">

      <li class="nav-item">
        <a class="nav-link" href="<?php echo URLROOT; ?>/products">
          <i class="fa-solid fa-book"></i>
          <span class="ms-1 fs-6">Products</span>
        </a>
      </li>
    
    </ul>

    
  </div>
</nav>