<?php require APPROOT . '/views/admin/includes/header.php' ?>

<div class="container-fluid">
  <div class="row">

    <?php require APPROOT . '/views/admin/includes/sidebar.php' ?>

  </div>
</div>

