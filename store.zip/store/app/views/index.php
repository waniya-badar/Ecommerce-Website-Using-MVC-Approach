<?php require APPROOT . '/views/includes/header.php' ?>

<section class="hero">
  <div class="hero__content">
    <p class="text-white mt-3 mb-5">
      Wear Your Confidence
    </p>
    <h1 class="text-white">TRENDY PICKS, TIMELESS STYLE!</h1>
    <p class="text-white mt-3 mb-5">
      Discover fashion that defines you - shop the latest styles made to fit your vibe.
    </p>
  </div>
</section>

<section class="products">
  <div class="container">

    <div class="products__title">
      <h4>SHOP BY ITEMS</h4>
    </div>

    <div class="row g-5 justify-content-center products__content">
      <?php foreach ($data['products'] as $product) : ?>
        <div class="col-12 col-md-6 col-lg-4 product">
          <div class="card rounded-0">
            <a href="<?php echo URLROOT; ?>/products/show/<?php echo $product->product_id; ?>">
              <img class="card-img-top rounded-0" src="<?php echo URLROOT; ?>/images/products/<?php echo $product->image; ?>" alt="<?php echo $product->title; ?>">
            </a>
            <div class="card-body text-center">
              <a href="<?php echo URLROOT; ?>/products/show/<?php echo $product->product_id; ?>">
                <h5 class="card-title product__title"><?php echo $product->title; ?></h5>
              </a>
             
              <div class="card__footer">
                <p class="product__price text-muted">$<?php echo $product->price; ?></p>
                <a href="<?php echo URLROOT; ?>/products/show/<?php echo $product->product_id; ?>" class="btn  rounded-0  btn__details">DETAILS</a>
              </div>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>

  </div>
</section>

<section class="top__selling">

  <div class="top__selling__heading text-center">
    <h4 class="text-capitalize">Top Selling Products</h4>
  </div>

  <div class="top__selling__content">
    <div class="container">
      <div class="top__selling__container">
        <div class="top__selling__item">
          <div class="top__selling__image">
            <img src="<?php echo URLROOT; ?>/images/products/m1.png" class="w-100">
          </div>
          <div class="top__selling__info">
            <h5 class="text-capitalize">Polos</h5>
            <p class="text-secondary">Polos are great and modern!</p>
          </div>
        </div>
        <div class="top__selling__item">
          <div class="top__selling__image">
            <img src="<?php echo URLROOT; ?>/images/products/a1.png" class="w-100">
          </div>
          <div class="top__selling__info">
            <h5 class="text-capitalize">Tracksuits</h5>
            <p class="text-secondary">Perfect for gymming</p>
          </div>
        </div>
      </div>
    </div>
  </div>

</section>


