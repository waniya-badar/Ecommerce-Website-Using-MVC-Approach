<?php require APPROOT . '/views/includes/header.php' ?>

<section class="single__product">
  <div class="container">
    <div class="row g-5">
      <div class="col-12 col-md-6 col-lg-5">
        <div class="product__image">
          <img src="<?php echo URLROOT; ?>/images/products/<?php echo $data['product']->image; ?>" alt="<?php echo $data['product']->title; ?>" class="w-100">
        </div>
      </div>
      <div class="col-12 col-md-6 col-lg-7 border px-4 py-3 ">
        <div class="product__content">
          <h1 class="product__title"><?php echo $data['product']->title; ?></h1>
          <p class="product__price">$<?php echo $data['product']->price; ?></p>
          <p class="product__description"><?php echo $data['product']->product_description; ?></p>

        </div>
      </div>
    </div>
  </div>

</section>
