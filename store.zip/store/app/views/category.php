<?php require APPROOT . '/views/includes/header.php' ?>

<section class="products">
  <div class="container">
    <div class="products__title">
      <i class="fa-solid fa-down-long"></i>
      <h4>Discover Products</h4>
    </div>
    <div class="row g-5 justify-content-center products__content">
      <?php foreach ($data['products'] as $product) : ?>
        <div class="col-12 col-md-6 col-lg-4 product">
          <div class="card rounded-0">
            <a href="<?php echo URLROOT; ?>/products/show/<?php echo $product->product_id; ?>">
              <img class="card-img-top rounded-0" src="<?php echo URLROOT; ?>/images/products/<?php echo $product->image; ?>" alt="<?php echo $product->title; ?>">
            </a>
            <div class="card-body text-center">
              <a href="<?php echo URLROOT; ?>/products/show/<?php echo $product->product_id; ?>">
                <h5 class="card-title product__title"><?php echo $product->title; ?></h5>
              </a>
              <p class="product__price">$<?php echo $product->price; ?></p>
              <a href="<?php echo URLROOT; ?>/products/show/<?php echo $product->product_id; ?>" class="btn  rounded-0 px-5 py-2 btn__details">DETAILS</a>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

