<?php

class Home extends Controller
{

  public function __construct()
  {
    $this->productModel = $this->model('Product');
    $this->categoryModel = $this->model('Category');
  }

  public function index()
  {
    $products = $this->productModel->get_products();
    $categories = $this->categoryModel->get_categories();

    $data = [
      'products' => $products,
      'categories' => $categories,
    ];

    $this->view('index', $data);
  }
}
