<?php

class Admin extends Controller
{

  public function __construct()
  {
    $this->categoryModel = $this->model('Category');
    $this->productModel = $this->model('Product');
  }

  public function index()
  {

    if (!isset($_SESSION["user_role"]) || $_SESSION["user_role"] !== 1) {
      $this->redirect('/');
    }

    $categories = $this->categoryModel->get_categories();
    $products = $this->productModel->get_products();

    $data = [
      'categories' => $categories,
      'products' => $products,
    ];

    $this->view('admin/index', $data);
  }
}
