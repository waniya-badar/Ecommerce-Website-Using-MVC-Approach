<?php

class Categories extends Controller
{
  public function __construct()
  {
    if (!isset($_SESSION["user_role"]) || $_SESSION["user_role"] !== 1) {
      $this->redirect('/');
    }

    $this->categoryModel = $this->model('Category');
  }

  public function index()
  {
    $categories = $this->categoryModel->get_categories();
    $data = [
      'categories' => $categories
    ];
    $this->view('admin/categories/index', $data);
  }

}