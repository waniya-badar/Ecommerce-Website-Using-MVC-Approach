<?php

class Products extends Controller
{

  public function __construct()
  {
    $this->productModel = $this->model('Product');
    $this->categoryModel = $this->model('Category');
  }

  public function index()
  {
    $products = $this->productModel->get_products();

    $data = [
      'products' => $products,
    ];

    $this->view('admin/products/index', $data);
  }

  public function create()

  {
    if (!isset($_SESSION["user_role"]) || $_SESSION["user_role"] !== 1) {
      $this->redirect('/');
    }

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {

      $data = [
        'category_id' => $_POST['category_id'],
        'title' => $_POST['title'],
        'description' => $_POST['description'],
        'image' => $_FILES['image']['name'],
        'price' => $_POST['price'],

        'category_id_error' => '',
        'title_error' => '',
        'description_error' => '',
        'image_error' => '',
        'price_error' => '',
      ];


      if (empty($data['category_id'])) {
        $data['category_id_error'] = 'Category is required';
      }

      if (empty($data['title'])) {
        $data['title_error'] = 'Title is required';
      }

      if (empty($data['description'])) {
        $data['description_error'] = 'Description is required';
      }

      if (empty($data['image'])) {
        $data['image_error'] = 'Image is required';
      }

      if (empty($data['price'])) {
        $data['price_error'] = 'Price is required';
      }

      if (
        empty($data['category_id_error']) &&
        empty($data['title_error']) &&
        empty($data['description_error']) &&
        empty($data['image_error']) &&
        empty($data['price_error'])

      ) {
        $this->productModel->category_id = $data['category_id'];
        $this->productModel->title = $data['title'];
        $this->productModel->description = $data['description'];
        $this->productModel->image = $data['image'];
        $this->productModel->price = $data['price'];
        $this->productModel->add_product();

        move_uploaded_file($_FILES['image']['tmp_name'], 'images/products/' . $data['image']);

        $this->redirect('/products');
      } else {
        $this->view('admin/products/create', $data);
      }
    } else {

      $categories = $this->categoryModel->get_categories();

      $data = [
        'title' => '',
        'description' => '',
        'image' => '',
        'price' => '',
        'categories' => $categories,
      ];
      $this->view('admin/products/create', $data);
    }
  }

  public function update($id)
  {
    if (!isset($_SESSION["user_role"]) || $_SESSION["user_role"] !== 1) {
      $this->redirect('/');
    }

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {

      $data = [
        'category_id' => $_POST['category_id'],
        'title' => $_POST['title'],
        'description' => $_POST['description'],
        'image' => $_FILES['image']['name'],
        'price' => $_POST['price'],

        'category_id_error' => '',
        'title_error' => '',
        'description_error' => '',
        'image_error' => '',
        'price_error' => '',
      ];

      if (empty($data['category_id'])) {
        $data['category_id_error'] = 'Category is required';
      }

      if (empty($data['title'])) {
        $data['title_error'] = 'Title is required';
      }

      if (empty($data['description'])) {
        $data['description_error'] = 'Description is required';
      }

      if (empty($data['image'])) {
        $data['image_error'] = 'Image is required';
      }

      if (empty($data['price'])) {
        $data['price_error'] = 'Price is required';
      }

      if (
        empty($data['category_id_error']) &&
        empty($data['title_error']) &&
        empty($data['description_error']) &&
        empty($data['image_error']) &&
        empty($data['price_error'])
      ) {
        $this->productModel->category_id = $data['category_id'];
        $this->productModel->title = $data['title'];
        $this->productModel->description = $data['description'];
        $this->productModel->image = $data['image'];
        $this->productModel->price = $data['price'];
        $this->productModel->update_product($id);

        move_uploaded_file($_FILES['image']['tmp_name'], 'images/products/' . $data['image']);

        $this->redirect('/products');
      } else {
        $this->view('admin/products/update', $data);
      }
    } else {

      $product = $this->productModel->get_product($id);

      $categories = $this->categoryModel->get_categories();

      $data = [
        'id' => $id,
        'category_id' => $product->category_id,
        'title' => $product->title,
        'description' => $product->product_description,
        'image' => $product->image,
        'price' => $product->price,

        'categories' => $categories,
      ];

      $this->view('admin/products/update', $data);
    }
  }

  public function show($id)
  {

    $product = $this->productModel->get_product($id);
    $categories = $this->categoryModel->get_categories();


    $data = [
      'product' => $product,
      'categories' => $categories,
    ];

    $this->view('show', $data);
  }

  public function delete($id)
  {
    $this->productModel->id = $id;
    $this->productModel->delete_product();
    $this->redirect('/products');
  }

  public function category($category_id)
  {
    if (!isset($_SESSION["user_id"])) {
      $this->redirect('/users/login');
    }
    $products = $this->productModel->get_products_by_category($category_id);
    $categories = $this->categoryModel->get_categories();

    $data = [
      'products' => $products,
      'categories' => $categories,
    ];

    $this->view('category', $data);
  }

  public function myproducts($user_id)
  {
    $products = $this->cartModel->get_cart_by_user_id($user_id);
    $categories = $this->categoryModel->get_categories();

    $data = [
      'products' => $products,
      'categories' => $categories,
    ];

    $this->view('myproducts', $data);
  }

  
}
