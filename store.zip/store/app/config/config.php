<?php

session_start();

define('DB_HOST', 'localhost');
define('DB_NAME', 'store');
define('DB_USER', 'root');
define('DB_PASSWORD', '');

define('APPROOT', dirname(dirname(__FILE__)));
define('URLROOT', 'http://localhost/store');
define('SITENAME', 'ONLINE SHOPPING STORE');
